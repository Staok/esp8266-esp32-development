# MicroPython-ESP32固件烧录-1Z实验室

教程搬家到: 
http://www.1zlab.com/article/micropython-esp32-firmware-upload/