sudo esptool.py --chip esp32 --port /dev/ttyUSB0 write_flash -z  0x1000 esp32spiram-20180919-v1.9.4-543-gdc77fdb7d.bin
