from led import LED
# 提示: 你也可以尝试LED(1)
# 创建一个LED对象
led0 = LED(0)

# 开启LED
led0.on()

# 关闭LED
# led0.off()

# 切换LED的状态
# led0.toggle()