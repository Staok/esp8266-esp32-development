 # 延时函数与LED闪烁

教程搬家至
http://www.1zlab.com/article/micropython-esp32-delay-and-led-blink/