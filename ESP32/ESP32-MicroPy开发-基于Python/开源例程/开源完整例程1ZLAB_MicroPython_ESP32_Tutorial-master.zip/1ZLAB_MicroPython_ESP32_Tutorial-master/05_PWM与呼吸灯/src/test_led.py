from led import LED

# 实例化一个LED
led = LED(0)
# 设置LED的亮度
led.intensity(500)