# GPIO输入与用户按键控制LED开关-1Z实验室


教程搬家到: 

http://www.1zlab.com/article/micropython-esp32-gpio-output-button-control-led/