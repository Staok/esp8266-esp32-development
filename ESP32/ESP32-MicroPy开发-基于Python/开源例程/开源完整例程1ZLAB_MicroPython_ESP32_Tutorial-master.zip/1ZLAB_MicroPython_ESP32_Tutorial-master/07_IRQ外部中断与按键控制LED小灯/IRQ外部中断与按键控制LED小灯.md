# IRQ外部中断与按键控制LED小灯

教程搬家到:
http://www.1zlab.com/article/micropython-esp32-irq-interrupt-and-button-control-led/
