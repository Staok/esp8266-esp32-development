

# ADC采样与电位计控制LED亮度

教程搬家至: 
http://www.1zlab.com/article/micropython-esp32-adc-sample-and-encoder-control-led/