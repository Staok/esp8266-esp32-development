

# Timer定时器与LED闪烁

教程搬家至: 
http://www.1zlab.com/article/micropython-esp32-timer-and-led-blink/