
# UART串口通信-MicroPython-ESP32-1Z实验室

教程搬家至:
http://www.1zlab.com/article/micropython-esp32-uart-communication/